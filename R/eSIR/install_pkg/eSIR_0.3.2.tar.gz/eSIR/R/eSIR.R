#' @import rjags
#' @import scales
#' @import ggplot2
#' @import chron
#' @import gtools
#' @import data.table
#' @import stats
#' @import grDevices
#' @import graphics
#' @import utils
#' @importFrom coda as.mcmc.list
NULL
